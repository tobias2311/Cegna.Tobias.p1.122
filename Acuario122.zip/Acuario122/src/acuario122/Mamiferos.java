/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package acuario122;

import java.util.Objects;

/**
 *
 * @author tobia
 */
public class Mamiferos extends Animales implements Nadar, BuscarAlimento{
    private int frecuenciaRespiración;

    public Mamiferos(int frecuenciaRespiración, String nombre, String habitat, TipoAgua tipoagua) {
        super(nombre, habitat, tipoagua);
        this.frecuenciaRespiración = frecuenciaRespiración;
    }

    public int getFrecuenciaRespiración() {
        return frecuenciaRespiración;
    }

    @Override
    public void puedenNadar() {
        System.out.println("los mamiferos pueden nadar");
    }

    @Override
    public void alimento() {
        System.out.println("los mamiferos pueden buscar comida");
    }
    
     @Override
    public int hashCode() {
        return Objects.hash(frecuenciaRespiración);
    }
    
     @Override
    public boolean equals(Object o){
        if(!super.equals(o)) return false;
        
        Mamiferos m = (Mamiferos) o;
        
        return m.getFrecuenciaRespiración()== this.frecuenciaRespiración;
    }

    @Override
    public String toString() {
        return super.toString() +  " Mamiferos " + " frecuenciaRespiracin " + frecuenciaRespiración;
    }
    
    
}
