/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package acuario122;

import java.util.Objects;

/**
 *
 * @author tobia
 */
public class Peces extends Animales implements Nadar{
 private double longitudmaxima;

    public Peces(double longitudmaxima, String nombre, String habitat, TipoAgua tipoagua) {
        super(nombre, habitat, tipoagua);
        this.longitudmaxima = longitudmaxima;
    }

    public double getLongitudmaxima() {
        return longitudmaxima;
    }

    @Override
    public void puedenNadar() {
        System.out.println("los peces pueden nadar");
    }
    
     @Override
    public int hashCode() {
        return Objects.hash(longitudmaxima);
    }
    
     @Override
    public boolean equals(Object o){
        if(!super.equals(o)) return false;
        
        Peces p = (Peces) o;
        
        return p.getLongitudmaxima()== this.longitudmaxima;
    }

    @Override
    public String toString() {
        return super.toString() + " Peces " + "longitudmaxima " + longitudmaxima;
    }
    
    
}