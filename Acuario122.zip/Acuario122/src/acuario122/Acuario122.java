/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package acuario122;

/**
 *
 * @author tobia
 */
public class Acuario122 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Acuario acua = new Acuario("Acuario Marino");

        Peces p1 = new Peces(7, "Nemo", "tanque tropical", TipoAgua.SALADA);
        Peces p2 = new Peces(7, "Nemo", "tanque tropical", TipoAgua.SALADA);
        Mamiferos mami1 = new Mamiferos(10, "fefi", "tanque australianos", TipoAgua.SALADA);
        Mamiferos mami2 = new Mamiferos(6, "lupo", "tanque irlandes", TipoAgua.DULCE);
        Crustaceos cru1 = new Crustaceos(4, "gugu", "oceano", TipoAgua.DULCE);
        Crustaceos cru2 = new Crustaceos(4, "pepe", "oceano", TipoAgua.SALADA);

        acua.agregarAnimal(p1);
        acua.agregarAnimal(p2);
        acua.agregarAnimal(p1);
        acua.agregarAnimal(mami1);
        acua.agregarAnimal(mami2);
        acua.agregarAnimal(cru1);
        acua.agregarAnimal(cru2);

        System.out.println("\nMOSTRANDO ANIMALES");
        acua.mostrarAnimales();
        
        System.out.println("\nNADO Y BUSQUEDA DE COMIDA");
        acua.buscarAlimento();
        acua.nadar();
        
        System.out.println("\nTIPO DE ANIMAL");
        acua.mostrarAnimalesPorTipo("Mamiferos");
        
        System.out.println("\nTIPO DE AGUA");
        acua.filtrarPorTipoAgua(TipoAgua.DULCE);

        

    }

}
