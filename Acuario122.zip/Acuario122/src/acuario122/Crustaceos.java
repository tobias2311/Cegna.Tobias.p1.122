package acuario122;

import java.util.Objects;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author tobia
 */
public class Crustaceos extends Animales implements BuscarAlimento{
    private int patas;

    public Crustaceos(int patas, String nombre, String habitat, TipoAgua tipoagua) {
        super(nombre, habitat, tipoagua);
        this.patas = patas;
    }

    public int getPatas() {
        return patas;
    }

    @Override
    public void alimento() {
        System.out.println("los crustaceos pueden buscar comida");
    }
    
    
    @Override
    public int hashCode() {
        return Objects.hash(patas);
    }
    
    @Override
    public boolean equals(Object o){
        if(!super.equals(o)) return false;
        
        Crustaceos c = (Crustaceos) o;
        
        return c.getPatas()== this.patas;
    }

    @Override
    public String toString() {
        return super.toString() + " Crustaceos " + " patas " + patas;
    }
    
    
    
}
