/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package acuario122;

/**
 *
 * @author tobia
 */
public class AnimalExistente extends Exception {
    private final static String MESSAGE = "esta especie ya existe";

    public AnimalExistente(String message) {
        super(message);
    }
    
    public AnimalExistente() {
        this(MESSAGE);
    }
}
