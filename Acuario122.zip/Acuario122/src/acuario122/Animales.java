/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package acuario122;

import java.util.Objects;

/**
 *
 * @author tobia
 */
public abstract class Animales {
      private String nombre;
    private String habitat;
    private TipoAgua tipoagua;

    public Animales(String nombre, String habitat, TipoAgua tipoagua) {
        this.nombre = nombre;
        this.habitat = habitat;
        this.tipoagua = tipoagua;
    }

    public String getNombre() {
        return nombre;
    }

    public String getHabitat() {
        return habitat;
    }

    public TipoAgua getTipoagua() {
        return tipoagua;
    }
    
     @Override
    public int hashCode() {
        return Objects.hash(nombre, habitat, tipoagua);
    }
    
     @Override
    public boolean equals(Object o){
       if(o == null ||  o.getClass() != this.getClass()) return false;
       
       Animales a = (Animales) o;
       
       return a.getNombre().equals(this.nombre) && a.getHabitat().equals(this.habitat) && a.getTipoagua().equals(this.tipoagua);
    }

    @Override
    public String toString() {
        return "Animales " + "nombre " + nombre + ", habitat " + habitat + ", tipoagua " + tipoagua;
    }
    
       
}

