/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package acuario122;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 *
 * @author tobia
 */
public class Acuario {

    private String nombre;
    private List<Animales> listaAnimales;

    public Acuario() {
        this.listaAnimales = new ArrayList<>();
    }

    public Acuario(String nombre) {
        this();
        this.nombre = nombre;

    }

    public String getNombre() {
        return nombre;
    }

    public void agregarAnimal(Animales animal) {
        try {
            validarAnimalesNula(animal);
             validarAnimalesRepetida(animal);
            listaAnimales.add(animal);
        } catch (NullPointerException | AnimalExistente a) {
            System.out.println(a.getMessage());
        }
    }

    public void mostrarAnimales() {
        for (Animales e : listaAnimales) {
            System.out.println(e);
        }

    }

    public void nadar() {
        for (Animales a : listaAnimales) {
            if (a instanceof Nadar) {
                ((Nadar) a).puedenNadar();
            } else {
                System.out.println("el crustaceo no puede nadar");
            }
        }
    }

    public void buscarAlimento() {
        for (Animales a : listaAnimales) {
            if (a instanceof BuscarAlimento) {
                ((BuscarAlimento) a).alimento();
            } else {
                System.out.println("el pez no puede buscar comida");
            }
        }
    }

    public ArrayList<Animales> filtrarPorTipoAgua(TipoAgua tipo) {
        ArrayList<Animales> lista = new ArrayList<>();
        for (Animales a : listaAnimales) {
            if (a.getTipoagua().equals(tipo)) {
                System.out.println(a);
                lista.add(a);
            }

        }
        return lista;
    }

    public void mostrarAnimalesPorTipo(String tipoAnimal) {
        for (Animales a : listaAnimales) {
            if (a.getClass().getSimpleName().equals(tipoAnimal)) {
                System.out.println(a.toString());
            }
        }
    }
    
    private void validarAnimalesNula(Animales e) {
        if (e == null) {
            throw new NullPointerException();
        }
    }
    
    private void validarAnimalesRepetida(Animales ani) throws AnimalExistente {
        for (Animales a : listaAnimales) {
            if (a.equals(ani)) {
                throw new AnimalExistente();
            }
        }
    }
    
     @Override
    public int hashCode() {
        return Objects.hash(nombre);
    }
    
    @Override
    public boolean equals(Object o) {
        if (o == null || o.getClass() != this.getClass()) {
            return false;
        }

        Acuario p = (Acuario) o;
        return p.getNombre().equals(this.nombre);
    }

    @Override
    public String toString() {
        return "Acuario " + "nombre " + nombre;
    }
    
    
}
